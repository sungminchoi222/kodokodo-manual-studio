# MANUAL STUDIO — 개발 명세 패키지 v1

파일 구성:

1. `01_PRODUCT_STANDARDS_AND_EXPORT_SPEC_KR.md` — HQ Product Standards/필드검증/브랜드 권한/PPTX-PDF 출력 계약/DB/API/테스트 상세 명세.
2. `02_CLAUDE_CODE_IMPLEMENTATION_PROMPT.md` — Claude Code에 바로 넣을 첫 지시문.
3. `03_SAMPLE_EXPORT_DOCUMENT.json` — 승인 이전 DEMO 데이터의 공통 ExportDocument 예시. 유효한 식품안전/보관기한 기준이 아님.

## 사용 순서

1. 폴더 전체를 로컬 프로젝트 작업 디렉터리에 넣기.
2. Claude Code에서 폴더를 열어 `02_CLAUDE_CODE_IMPLEMENTATION_PROMPT.md`를 실행 지시로 전달하기.
3. 1차로 파일 구조/DB/화면 설계를 검토하고 승인.
4. 이후 Field 입력과 HQ 편집기 → 승인/version → 개별 PPTX/PDF → Combined PPTX/PDF 순서로 구현.

**별도 프로젝트:** 게임(KODO KODO TYCOON), Equipment Master와 분리.
